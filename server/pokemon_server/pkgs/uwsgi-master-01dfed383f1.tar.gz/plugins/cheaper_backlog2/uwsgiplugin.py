NAME='cheaper_backlog2'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['cheaper_backlog2']

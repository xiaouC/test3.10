
def loop():
    pass

# coding: utf-8

class ConnectionClosed(Exception):
    pass

class CloseServer(Exception):
    pass

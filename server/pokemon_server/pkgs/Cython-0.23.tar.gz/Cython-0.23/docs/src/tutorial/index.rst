Tutorials
=========

.. toctree::
   :maxdepth: 2

   cython_tutorial
   external
   clibraries
   cdef_classes
   pxd_files
   caveats
   profiling_tutorial
   strings
   memory_allocation
   pure
   numpy
   array
   readings
   related_work
   appendix


# mode: compile

class A:
    def foo(self):
        return "A"

class B(A):
    def foo(self):
        return "B"

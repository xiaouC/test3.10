# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod
from HJSDK.config import config
import json
import urllib
import urllib2
import time
import uuid
import hmac
import hashlib
import xml.etree.ElementTree
import urlparse
import random


def get_channel_instance(json_str):
    auth_object = json.loads(json_str)
    proxy = auth_object['channel'].capitalize()
    if proxy == 'Coolpad':
        obj = CoolpadAuth()
    elif proxy == 'Oppo':
        obj = OppoAuth()
    elif proxy == 'Huawei':
        obj = HuaweiAuth()
    elif proxy == 'Lenovo':
        obj = LenovoAuth()
    elif proxy == 'Gionee':
        obj = GioneeAuth()
    elif proxy == 'Vivo':
        obj = VivoAuth()
    else:
        obj = False

    if obj:
        obj.authCode = auth_object['auth_code']
        obj.accessToken = auth_object['access_token']
        obj.tokenSecret = auth_object['token_secret']

    return obj


class AuthBase:
    # 登录基类

    __metaclass__ = ABCMeta

    URLLIB2_TIME_OUT = 10

    authCode = ''
    accessToken = ''
    tokenSecret = ''

    def __init__(self):
        pass

    @abstractmethod
    def invoke_service(self):
        pass

    def http_service_accessor(self, url, post=False, param=None, authorization=None):
        try:
            request = urllib2.Request(url)

            if post:
                request.get_method = lambda: 'POST'

            if param is not None:
                if isinstance(param, dict):
                    param = urllib.urlencode(param)
                request.add_data(param)

            if authorization is not None:
                request.add_header('Authorization', authorization)

            return urllib2.urlopen(request, timeout=self.URLLIB2_TIME_OUT).read()
        except urllib2.HTTPError:
            return False


class CoolpadAuth(AuthBase):
    # 酷派验证登录

    URL_PREFIX = 'https://openapi.coolyun.com/oauth2/'

    def invoke_service(self):
        auth_code = self.authCode
        if len(auth_code) == 0:
            return {'errMsg': 'authCode不能为空'}

        qs = urllib.urlencode({
            'grant_type': 'authorization_code',
            'client_id': config['COOLPAD_APP_ID'],
            'client_secret': config['COOLPAD_APP_KEY'],
            'redirect_uri': config['COOLPAD_APP_KEY'],
            'code': auth_code,
        })
        url = self.URL_PREFIX + 'token?' + qs

        result = self.http_service_accessor(url)

        if result is False:
            return {'errMsg': '网络连接异常'}

        result = json.loads(result)

        if 'error' in result and result['error'] != '0':
            return {'errMsg': self.__error[int(result['error'])]}

        ret_data = {
            'access_token': result['access_token'],
            'open_id': result['openid'],
            'expires_in': result['expires_in'],
            'refresh_token': result['refresh_token'],
            'channel': 'coolpad'
        }

        # 生成获取用户信息的 query string
        qs = urllib.urlencode({
            'access_token': ret_data['access_token'],
            'oauth_consumer_key': config['COOLPAD_APP_ID'],
            'openid': ret_data['open_id']
        })

        # 登录后获取用户信息，酷派要求必须接入这个接口
        url = self.URL_PREFIX + 'api/get_user_info?' + qs
        result = self.http_service_accessor(url)

        # 不校验这个接口的返回成功与否，对支付无实际意义
        result = json.loads(result)
        ret_data['user_name'] = result['nickname']
        return ret_data

    __error = {
        0: '成功。',
        2000: '缺少参数response_type或response_type非法。',
        2001: '缺少参数client_id。',
        2002: '缺少参数client_secret。',
        2003: 'http head中缺少Authorization。',
        2004: '缺少参数grant_type或grant_type非法。',
        2005: '缺少参数code。',
        2006: '缺少refresh token。',
        2007: '缺少access token。',
        2008: '该appid不存在。',
        2009: 'client_secret（即appkey）非法。',
        2010: '回调地址不合法，常见原因请见：回调地址常见问题及修改方法',
        2011: 'APP不处于上线状态。',
        2012: 'HTTP请求非post方式。',
        2013: 'access token非法。',
        2014: 'access token过期。',
        2015: 'access token废除。',
        2016: 'access token验证失败。',
        2017: '获取appid失败。',
        2018: '获取code值失败。',
        2019: '用code换取access token值失败。',
        2020: 'code被重复使用。',
        2021: '获取access token值失败。',
        2022: '获取refresh token值失败。',
        2023: '获取app具有的权限列表失败。',
        2024: '获取某OpenID对某appid的权限列表失败。',
        2025: '获取全量api信息、全量分组信息。',
        2026: '设置用户对某app授权api列表失败。',
        2027: '设置用户对某app授权时间失败。',
        2028: '缺少参数which。',
        2029: '错误的http请求。',
        2030: '用户没有对该api进行授权，或用户在腾讯侧删除了该api的权限。请用户重新走登录、授权流程，对该api进行授权。',
        2031: '第三方应用没有对该api操作的权限。请发送邮件进行OpenAPI权限申请。',
        3000: 'HTTP错误',
        3001: 'HTTP请求错误',
        3002: 'HTTP响应错误',
        3003: 'HTTP接收数据出现错误',
        3004: '客户端协议错误',
        3005: 'HTTP请求时发生IO错误',
        3006: '网络不可用',
        4002: 'SSO服务未安装',
        4003: 'SSO服务启动失败',
        4006: '远程调用失败',
        4011: '不支持该请求'
    }


class GioneeAuth(AuthBase):
    # 金立验证登录

    URL_PREFIX = 'https://id.gionee.com/account/verify.do'

    def invoke_service(self):
        access_token = self.accessToken
        if len(access_token) == 0:
            return {'errMsg': 'accessToken不能为空'}

        api_key = config['GIONEE_API_KEY']
        secret_key = config['GIONEE_SECRET_KEY']
        amigo_token = access_token
        ts = str(int(time.time()))
        nonce = str(uuid.uuid1())[0:8].upper()

        signature_str = ts+'\n'+nonce+'\nPOST\n/account/verify.do\nid.gionee.com\n443\n\n'
        signature = hmac.new(secret_key, signature_str, hashlib.sha1).digest().encode("base64").rstrip('\n')
        authorization = 'MAC id="'+api_key+'",ts="'+ts+'",nonce="'+nonce+'",mac="'+signature+'"'
        result = self.http_service_accessor(self.URL_PREFIX, True, amigo_token, authorization)

        if result is False:
            return {'errMsg': '网络连接异常'}

        result = json.loads(result)

        if 'r' in result:
            err_msg = result['err'] or self.__error[int(result['r'])]
            return {'errMsg': err_msg}

        ret_data = {
            'access_token': access_token,
            'open_id': result['u'],
            'user_name': result['tn'],
            'expires_in': '',
            'refresh_token': '',
            'channel': 'gionee'
        }
        return ret_data

    __error = {
        1011: '认证失败',
        1020: 'Amigo 账号服务器内部错误',
        1031: '发送超时',
        1050: 'MAC 签名的 timestamp 已过期',
        1051: 'MAC 签名的 nonce 重复'
    }


class HuaweiAuth(AuthBase):

    URL_PREFIX = 'https://api.vmall.com/rest.php?nsp_svc=OpenUP.User.getInfo&nsp_ts='

    def invoke_service(self):
        access_token = self.accessToken
        if len(access_token) == 0:
            return {'errMsg': 'accessToken不能为空'}

        url = self.URL_PREFIX + str(int(time.time())) + '&access_token=' + urllib.quote(access_token)

        result = self.http_service_accessor(url)

        if result is False:
            return {'errMsg': '网络连接异常'}

        result = json.loads(result)
        if 'error' in result:
            return {'errMsg': result['error']}

        ret_data = {
            'access_token': access_token,
            'open_id': result['userID'],
            'user_name': result['userName'],
            'expires_in': '',
            'refresh_token': '',
            'channel': 'huawei'
        }
        return ret_data


class LenovoAuth(AuthBase):

    LOGIN_TOKEN_URL = 'http://passport.lenovo.com/interserver/authen/1.2/getaccountid'

    def invoke_service(self):
        token_secret = self.tokenSecret

        if len(token_secret) == 0:
            return {'errMsg': 'tokenSecret不能为空'}

        params = {
            # 此处 authCode 为联想的ST
            'lpsust': token_secret,
            'realm': config['OPEN_APP_ID']
        }
        url = self.LOGIN_TOKEN_URL + '?' + urllib.urlencode(params)
        xml_content = self.http_service_accessor(url)

        if xml_content is None:
            return {'errMsg': '网络连接异常'}

        root = xml.etree.ElementTree.fromstring(xml_content)
        result = {}
        for child in root:
            result[child.tag] = child.text

        if 'Code' in result:
            return {'errMsg': self.__error[result['Code']]}

        ret_data = {
            'access_token': token_secret,
            'open_id': result['AccountID'],
            'user_name': result['Username'],
            'expires_in': '',
            'refresh_token': '',
            'channel': 'lenovo'
        }
        return ret_data

    __error = {
        'USS-0100': '无效的用户名，需要检查用户名格式是否正确。',
        'USS-0101': '口令错误。',
        'USS-0103': '无此用户，请检查用户名是否正确',
        'USS-0104': '用户名已存在，不允许重复注册',
        'USS-0105': '帐号必须激活后才能登录',
        'USS-0108': '该用户已激活，请勿重复操作。',
        'USS-0110': '无效的 IMEI，SN 或 MAC',
        'USS-0111': '帐号已被 disable',
        'USS-0113': '口令类型错误',
        'USS-0121': '无效的 realm',
        'USS-0122': '此服务不支持该 realm',
        'USS-0126': 'Ticket 值解析失败。',
        'USS-0135': '无效的请求数据',
        'USS-0151': '账号已锁定',
        'USS-0160': '需要使用验证码（在申请帐号时，如果服务端检测到异常行为，会返回该错误给客户端，客户端需要使用图形验证码）',
        'USS-0170': '密码格式错误。(密码的限制规则是: 4～20 位字符，包括英文大小写字母、英文数字、减号和下划线)',
        'USS-0181': '校验码错误或失效，针对手机账号对账号校验时可能产生',
        'USS-0190': '(针对短信注册，服务端不支持该运营商的号码。) 尚未开通，请尝试其他方式注册。',
        'USS-0540': '无效的 lpsust',
        'USS-0542': '未提供 lpsust 信息',
        'USS-0202': '用户登录已失效',
        'USS-0x0000': '后台快捷登录使用次数达到 10 次',
        'USS-0x0001': '后台快捷登录失败',
        'USS-0x0002': '后台快捷登录检测到未安装联想通行证'
    }


class OppoAuth(AuthBase):

    NM_UC_SERVER = 'http://thapi.nearme.com.cn/account/GetUserInfoByGame'
    token = ''
    secret = ''
    params = False

    def invoke_service(self):
        token = self.accessToken
        token_secret = self.tokenSecret

        if len(token) == 0 or len(token_secret) == 0:
            return {'errMsg': 'token或tokenSecret不能为空'}

        user = self.__get_user_info(token_secret, token)

        if user is None:
            return {'errMsg': '网络连接异常'}

        if 'errorCode' in user:
            result = urlparse.parse_qs(urllib.unquote_plus(user))
            err_msg = result['errorMsg'][0]
            return {'errMsg': err_msg}
        else:
            result = json.loads(user)
            result = result['BriefUser']

            # 拿到登录参数后解析，换掉下列值
            ret_data = {
                'access_token': token,
                'open_id': result['id'],
                'user_name': result['userName'],
                'expires_in': '',
                'refresh_token': '',
                'channel': 'oppo'
            }
            return ret_data

    def __get_params(self):
        nowtime = time.time()
        if not self.params:
            self.params = {
                'oauth_consumer_key': config['OPPO_CONSUMER_KEY'],
                'oauth_nonce': int(nowtime) + random.uniform(0, 9),
                'oauth_signature_method': 'HMAC-SHA1',
                'oauth_timestamp': int(nowtime*1000),
                'oauth_token': self.token,
                'oauth_version': '1.0'
            }
        return self.params

    def __get_param_string(self):
        return urllib.urlencode(self.__get_params())

    def __get_base_string(self):
        return "POST&" + urllib.quote_plus(self.NM_UC_SERVER) + '&' + urllib.quote_plus(self.__get_param_string())

    def __signature(self):
        return urllib.quote_plus(hmac.new(config['OPPO_SHA1_KEY_BASE'] + '&' + self.secret, self.__get_base_string(),
                                          hashlib.sha1).digest().encode("base64").rstrip('\n'))

    def __get_authorization(self):
        params = self.__get_params()
        params['signature'] = self.__signature()
        authorization = ''

        for i in params:
            if authorization == '':
                authorization += 'OAuth ' + i + '="' + str(params[i]) + '"'
            else:
                authorization += ',' + i + '="' + str(params[i]) + '"'

        return authorization

    def __get_user_info(self, secret=None, token=None):
        if secret:
            self.secret = secret
        if token:
            self.token = token
        authorization = self.__get_authorization()

        return self.http_service_accessor(self.NM_UC_SERVER, post=True, authorization=authorization)


class VivoAuth(AuthBase):

    URL_PREFIX = 'https://usrsys.inner.bbk.com/auth/user/info?access_token='
    SUCCESS_CODE = 200

    def invoke_service(self):
        access_token = self.accessToken
        if len(access_token) == 0:
            return {'errMsg': 'accessToken不能为空'}

        url = self.URL_PREFIX + access_token
        result = self.http_service_accessor(url)

        if result is False:
            return {'errMsg': '网络连接异常'}

        result = json.loads(result)

        if 'stat' in result and self.SUCCESS_CODE != result['stat']:
            return {'errMsg': result['msg']}

        ret_data = {
            'access_token': access_token,
            'open_id': result['uid'],
            'user_name': '',
            'expires_in': '',
            'refresh_token': '',
            'channel': 'vivo'
        }
        return ret_data
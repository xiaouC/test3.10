# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod
from HJSDK.config import config
import urllib
import urllib2
import time
import json
import M2Crypto
import hashlib
import base64


def chunk_split(body, chunk_len=64, end="\n"):
        ret_data = ""
        for i in xrange(0, len(body), chunk_len):
            ret_data += body[i:min(i + chunk_len, len(body))] + end
        return ret_data


def get_channel_instance(json_str):
        arr = json.loads(json_str)
        proxy = arr['channel'].capitalize()
        if proxy == 'Gionee':
            obj = GioneeCreateOrder()
        elif proxy == 'Vivo':
            obj = VivoCreateOrder()
        elif proxy == 'Coolpad':
            obj = CoolpadCreateOrder()
        elif proxy == 'Huawei':
            obj = HuaweiCreateOrder()
        elif proxy == 'Lenovo':
            obj = LenovoCreateOrder()
        elif proxy == 'Oppo':
            obj = OppoCreateOrder()
        else:
            obj = False

        if obj:
            obj.playerId = arr['open_id']
            obj.userName = arr['user_name']
            obj.accessToken = arr['access_token']

        return obj


class OrderBase:
    __metaclass__ = ABCMeta

    playerId = ''
    userName = ''
    accessToken = ''

    CURL_TIME_OUT = 10

    def __init__(self):
        pass

    @abstractmethod
    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        pass

    def http_service_accessor(self, url, post_method=False, param=None, authorization=None):
        try:
            request = urllib2.Request(url)

            if post_method:
                request.get_method = lambda: 'POST'

            if param is not None:
                if isinstance(param, dict):
                    param = urllib.urlencode(param)
                request.add_data(param)

            if authorization is not None:
                request.add_header('Authorization', authorization)

            return urllib2.urlopen(request, timeout=self.CURL_TIME_OUT).read()
        except urllib2.HTTPError:
            return False


class CoolpadCreateOrder(OrderBase):
    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        ret_data = {
            'my_order_no': my_order_no,
            'channel_order_no': '',
            'order_id': my_order_no,
            'username': self.userName,
            'openid': self.playerId,
            'access_token': self.accessToken,
            'submit_time': '',
            'sign': '',
            'channel': 'coolpad'
        }
        return ret_data


class GioneeCreateOrder(OrderBase):
    CREATE_ORDER_URL = 'https://pay.gionee.com/order/create'
    SUCCESS_CODE = 200010000

    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        url = self.CREATE_ORDER_URL

        notify_url = config['GIONEE_NOTIFY_URL']
        # 如果有 cp_private_info 则添加这个参数
        if cp_private_info:
            if '?' not in notify_url:
                notify_url += '?'
            notify_url = notify_url + '&cpPrivateInfo=' + urllib.quote(cp_private_info)

        send_data = {
            'api_key': config['GIONEE_API_KEY'],
            'deal_price': money,        # 钱数已元为单元，可以传0.01，但必须是字符串！！！
            'deliver_type': '1',
            'notify_url': notify_url,
            'out_order_no': my_order_no,   # CP订单编号
            'subject': title,           # 订单表头
            'submit_time': time.strftime('%Y%m%d%H%M%S'),
            'total_fee': money
        }

        sign = self.__rsa_sign(send_data)
        send_data['sign'] = sign
        send_data['player_id'] = self.playerId
        send_data = json.dumps(send_data)
        result = self.http_service_accessor(url, True, send_data)
        result = json.loads(result)

        # 错误码判断
        if self.SUCCESS_CODE != int(result['status']):
            return {'errMsg': result['description']}

        ret_data = {
            'my_order_no': result['out_order_no'],
            'channel_order_no': result['order_no'],
            'order_id': result['out_order_no'],
            'username': self.userName,
            'openid': self.playerId,
            'access_token': self.accessToken,
            'submit_time': result['submit_time'],
            'sign': '',
            'channel': 'gionee'
        }
        return ret_data

    @staticmethod
    def __rsa_sign(contents):
        sorted_contents = sorted(contents.items())
        signature_str = ''.join('%s' % (str(v)) for k, v in sorted_contents)

        private_key = config['GIONEE_PRIVATE_KEY']
        pem = chunk_split(private_key)
        pem = "-----BEGIN PRIVATE KEY-----\n"+pem+"-----END PRIVATE KEY-----\n"
        pri_key = M2Crypto.EVP.load_key_string(pem)
        pri_key.sign_init()
        pri_key.sign_update(signature_str)
        signature = base64.b64encode(pri_key.sign_final())
        return signature


class HuaweiCreateOrder(OrderBase):
    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        ret_data = {
            'my_order_no': my_order_no,
            'channel_order_no': '',
            'order_id': my_order_no,
            'username': self.userName,
            'openid': self.playerId,
            'access_token': self.accessToken,
            'submit_time': '',
            'sign': '',
            'channel': 'huawei'
        }
        return ret_data


class LenovoCreateOrder(OrderBase):
    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        ret_data = {
            'my_order_no': my_order_no,
            'channel_order_no': '',
            'order_id': my_order_no,
            'username': self.userName,
            'openid': self.playerId,
            'access_token': self.accessToken,
            'submit_time': '',
            'sign': '',
            'channel': 'lenovo'
        }
        return ret_data


class OppoCreateOrder(OrderBase):
    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        ret_data = {
            'my_order_no': my_order_no,
            'channel_order_no': '',
            'order_id': my_order_no,
            'username': self.userName,
            'openid': self.playerId,
            'access_token': self.accessToken,
            'submit_time': '',
            'sign': '',
            'channel': 'oppo'
        }
        return ret_data


class VivoCreateOrder(OrderBase):
    CREATE_ORDER_URL = 'https://pay.vivo.com.cn/vcoin/trade'
    SUCCESS_CODE = 200

    def invoke_service(self, money, my_order_no, title, order_desc=None, cp_private_info=None):
        url = self.CREATE_ORDER_URL

        # 转为分为单位
        money = str(int(float(money) * 100))

        send_data = {
            'version': '1.0.0',
            'orderAmount': money,
            'cpOrderNumber': my_order_no,
            'orderTitle': title,
            'orderDesc': order_desc,
            'orderTime': time.strftime('%Y%m%d%H%M%S'),
            'cpId': config['VIVO_CP_ID'],
            'appId': config['VIVO_APP_ID'],
            'notifyUrl': config['VIVO_NOTIFY_URL']
        }

        if cp_private_info:
            send_data['extInfo'] = cp_private_info

        # 计算签名时不能带signMethod
        send_data['signature'] = self.__sign(send_data)
        send_data['signMethod'] = 'MD5'

        result = self.http_service_accessor(url, True, send_data)

        if not result:
            return {'errMsg': '网络连接异常'}

        result = json.loads(result)

        # 错误码判断
        if self.SUCCESS_CODE != int(result['respCode']):
            return {'errMsg': result['respMsg']}

        ret_data = {
            'my_order_no': my_order_no,
            'channel_order_no': result['orderNumber'],
            'order_id': result['orderNumber'],
            'username': self.userName,
            'openid': self.playerId,
            'access_token': result['accessKey'],
            'submit_time': send_data['orderTime'],
            'sign': result['signature'],    # 支付时需要的sign
            'channel': 'vivo'
        }
        return ret_data

    @staticmethod
    def __sign(contents):
        sorted_contents = sorted(contents.items())
        signature_str = '&'.join('%s=%s' % (str(k), str(v)) for k, v in sorted_contents if v != '')

        signature_str = hashlib.md5(signature_str + '&' + hashlib.md5(config['VIVO_CP_KEY']).hexdigest()).hexdigest()
        return signature_str
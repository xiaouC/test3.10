# -*- coding: utf-8 -*-

from abc import ABCMeta, abstractmethod
from HJSDK.config import config
import json
import hashlib
import M2Crypto
import base64


def chunk_split(body, chunk_len=64, end="\n"):
        data = ""
        for i in xrange(0, len(body), chunk_len):
            data += body[i:min(i + chunk_len, len(body))] + end
        return data


def get_channel_instance(channel_name):
    proxy = channel_name.capitalize()
    if proxy == 'Coolpad':
        obj = CoolpadNotify()
    elif proxy == 'Oppo':
        obj = OppoNotify()
    elif proxy == 'Huawei':
        obj = HuaweiNotify()
    elif proxy == 'Lenovo':
        obj = LenovoNotify()
    elif proxy == 'Gionee':
        obj = GioneeNotify()
    elif proxy == 'Vivo':
        obj = VivoNotify()
    else:
        obj = False

    return obj


def rsa_verify(pem, data, sign, algo='sha1'):
    pem = chunk_split(pem)
    pem = "-----BEGIN PUBLIC KEY-----\n" + pem + "-----END PUBLIC KEY-----\n"
    bio = M2Crypto.BIO.MemoryBuffer(pem)
    rsa = M2Crypto.RSA.load_pub_key_bio(bio)
    pubkey = M2Crypto.EVP.PKey(md=algo)
    pubkey.assign_rsa(rsa)
    pubkey.verify_init()
    pubkey.verify_update(data)
    signature = base64.b64decode(sign)
    return pubkey.verify_final(signature)


class NotifyBase:
    __metaclass__ = ABCMeta

    def __init__(self):
        pass

    @abstractmethod
    def invoke_service(self, post, get):
        pass

    @abstractmethod
    def send_response(self, resp):
        pass


class CoolpadNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        transdata = json.loads(post['transdata'])
        money = int(float(transdata['money']) * 100)

        ret_data = {
            'paySuccess':     1,
            'myOrderNo':      transdata['cporderid'],
            'channelOrderNo': transdata['transid'],
            'money':          money,  # 以分为单位，整形
            'cpPrivateInfo':  transdata['cpprivate'],
            'channel':        'coolpad'
        }

        return ret_data

    def send_response(self, resp='success'):
        if 'success' == resp:
            ret = 'SUCCESS'
        else:
            ret = 'FAILURE'

        return ret

    @staticmethod
    def __rsa_verify(contents):
        str_contents = str(contents['transdata'])
        sign = contents['sign']

        publickey = config['COOLPAD_PUBLIC_KEY']

        return rsa_verify(publickey, str_contents, sign, 'md5')


class GioneeNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        money = float(post['deal_price']) * 100

        ret_data = {
            'paySuccess':     1,
            'myOrderNo':      post['out_order_no'],
            'channelOrderNo': '',
            'money':          money,    # 以分为单位，整形
            'cpPrivateInfo':  get['cpPrivateInfo'],      # 以 GET 传输的 cpPrivateInfo 字段
            'channel':        'gionee'
        }

        return ret_data

    def send_response(self, resp='success'):
        if 'success' == resp:
            ret = 'success'
        else:
            ret = 'fail'

        return ret

    @staticmethod
    def __rsa_verify(contents):
        sorted_contents = sorted(contents.items())
        str_contents = '&'.join('%s=%s' % (str(k), str(v)) for k, v in sorted_contents if k != 'sign')

        publickey = config['GIONEE_PUBLIC_KEY']

        return rsa_verify(publickey, str_contents, contents['sign'])


class HuaweiNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        money = int(float(post['amount']) * 100)

        data = {
            'paySuccess':     1,
            'myOrderNo':      post['requestId'],
            'channelOrderNo': post['orderId'],
            'money':          money,  # 以分为单位，整形
            'cpPrivateInfo':  post['extReserved'],
            'channel':        'huawei'
        }

        return data

    def send_response(self, resp='success'):
        if 'success' == resp:
            ret = '{"result": 0}'
        else:
            ret = '{"result": 1}'

        return ret

    @staticmethod
    def __rsa_verify(contents):
        sorted_contents = sorted(contents.items())
        str_contents = '&'.join('%s=%s' % (str(k), str(v)) for k, v in sorted_contents if k != 'sign')

        publickey = config['HUAWEI_PUBLIC_KEY']

        return rsa_verify(publickey, str_contents, contents['sign'])


class LenovoNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        transdata = json.loads(post['transdata'])
        money = int(transdata['money'])

        data = {
            'paySuccess':     1,
            'myOrderNo':      transdata['exorderno'],
            'channelOrderNo': transdata['transid'],
            'money':          money,                    # 以分为单位，整形
            'cpPrivateInfo':  transdata['cpprivate'],
            'channel':       'lenovo'
        }

        return data

    def send_response(self, resp='success'):
        if 'success' == resp:
            ret = 'SUCCESS'
        else:
            ret = 'FAILURE'

        return ret

    @staticmethod
    def __rsa_verify(contents):
        sign = str(contents['sign'])
        str_contents = str(contents['transdata'])

        private_key = config['LENOVO_KEY']
        pem = chunk_split(private_key)
        pem = "-----BEGIN RSA PRIVATE KEY-----\n"+pem+"-----END RSA PRIVATE KEY-----\n"
        pri_key = M2Crypto.EVP.load_key_string(pem)
        pri_key.sign_init()
        pri_key.sign_update(str_contents)
        signature = base64.b64encode(pri_key.sign_final())

        return sign == signature


class OppoNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        money = int(post['price'])

        data = {
            'paySuccess':     1,
            'myOrderNo':      post['partnerOrder'],
            'channelOrderNo': post['notifyId'],
            'money':          money,                # 以分为单位，整形
            'cpPrivateInfo':  post['attach'],
            'channel':        'oppo'
        }

        return data

    def send_response(self, resp='success'):
        if 'success' == resp:
            ret = 'result=OK&resultMsg=success'
        else:
            ret = 'result=FAIL&resultMsg=fail'

        return ret

    @staticmethod
    def __rsa_verify(contents):
        str_contents = "notifyId=" + str(contents['notifyId']) + "&partnerOrder=" + str(contents['partnerOrder']) \
                       + "&productName=" + str(contents['productName']) + "&productDesc=" \
                       + str(contents['productDesc']) + "&price=" + str(contents['price']) + "&count=" \
                       + str(contents['count']) + "&attach=" + str(contents['attach'])

        publickey = config['OPPO_PUBLIC_KEY']

        return rsa_verify(publickey, str_contents, contents['sign'])


class VivoNotify(NotifyBase):
    def invoke_service(self, post, get):
        if not self.__rsa_verify(post):
            return False

        money = int(float(post['orderAmount']))

        ret_data = {
            'paySuccess':     1,
            'myOrderNo':      post['cpOrderNumber'],
            'channelOrderNo': post['orderNumber'],
            'money':          money,  # 以分为单位，整形
            'cpPrivateInfo':  post['extInfo'],
            'channel':       'vivo'
        }

        return ret_data

    def send_response(self, resp='success'):
        if 'success' == resp:
            return 'HTTP/1.1 200 OK'
        else:
            return 'HTTP/1.1 403 Forbidden'

    @staticmethod
    def __rsa_verify(contents):
        signature = contents['signature']
        del(contents['signMethod'])
        del(contents['signature'])

        sorted_contents = sorted(contents.items())
        signature_str = '&'.join('%s=%s' % (str(k), str(v)) for k, v in sorted_contents if v != '')

        signature_str = hashlib.md5(signature_str + '&' + hashlib.md5(config['VIVO_CP_KEY']).hexdigest()).hexdigest()
        return signature == signature_str

#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
#=============================================================================
#
#     FileName: sns_sig.py
#         Desc: 生成签名
#
#=============================================================================
'''
import urllib
import binascii
import hashlib
import hmac


def mk_soucrce(method, url_path, params):

    str_params = urllib.quote("&".join(k + "=" + str(params[k]) for k in sorted(params.keys())), '')

    source = '%s&%s&%s' % (
        method.upper(),
        urllib.quote(url_path, ''),
        str_params
    )

    return source


def hmac_sha1_sig(method, url_path, params, secret):
    source = mk_soucrce(method, url_path, params)
    hashed = hmac.new(secret, source, hashlib.sha1)
    return binascii.b2a_base64(hashed.digest())[:-1]


def mk_msdk_sig(appkey,  ts):
    str_params = str(appkey) + str(ts)
    import hashlib
    m = hashlib.md5()
    m.update(str_params)
    return m.hexdigest()


def main():

    method = 'GET'
    url_path = '/cgi-bin/video/video_insert'
    params = {
        'provider_id': 1,
        'src_id': 100,
        'name': 'test'
    }

    secret = '9b7adbd2ee5206224135&'

    print mk_soucrce(method, url_path, params)
    print hmac_sha1_sig(method, url_path, params, secret)

if __name__ == '__main__':
    main()

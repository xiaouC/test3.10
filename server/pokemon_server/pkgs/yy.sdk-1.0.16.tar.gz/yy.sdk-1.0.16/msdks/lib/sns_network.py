#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
#=============================================================================
#
#     FileName: sns_network.py
#         Desc: 开放平台的http协议发送包
#
#=============================================================================
'''

import socket
import copy
import urllib
import urllib2
from random import choice
import httplib

try:
    from urllib.parse import urlencode
except ImportError:
    from urllib import urlencode


class SNSNetwork(object):

    _iplist = ['msdktest.qq.com', ]

    def __init__(self, iplist=None):
        '''
        iplist:         ip列表，也可以传入域名
        '''
        if iplist:
            self._iplist = copy.deepcopy(iplist)

    def _http_send(self, method, url_path, cookie, ec_params):
        '''
        提供一个统一的调用API接口
        '''

        url = 'http://%s%s' % (choice(self._iplist), url_path)

        opener = urllib2.build_opener()

        if cookie:
            cookie = cookie
            opener.addheaders.append(('Cookie', "; ".join('%s=%s' % (k,v) for k,v in cookie.items())))

        if method.upper() == 'POST':
            data = opener.open(url, ec_params).read()
        elif method.upper() == 'GET':
            if ec_params:
                dest_url = '%s?%s' % (url, ec_params)
            else:
                dest_url = url
            data = opener.open(dest_url).read()
        else:
            raise TypeError('method invalid:%s' % method)

        return data

    def _https_send(self, method, url_path, cookie, ec_params):
        conn = httplib.HTTPSConnection(choice(self._iplist))

        method = method.upper()

        if method == 'GET':
            url = '%s?%s' % (url_path, ec_params)
            conn.request(method, url, headers={'Cookie': cookie})
        else:
            conn.request(method, url_path, ec_params, headers={'Cookie': cookie})

        rsp = conn.getresponse()

        if rsp.status != 200:
            raise (ValueError, 'status:%d' % rsp.status)
        data = rsp.read()

        return data

    def open(self, method, url_path, params, cookie, protocol='http'):
        '''
        对外提供使用
        '''

        ec_params = self.mk_send_data(copy.deepcopy(params))
        cookie = copy.deepcopy(cookie)

        if protocol == 'http':
            data = self._http_send(method, url_path, cookie, ec_params)
        elif protocol == 'https':
            data = self._https_send(method, url_path, cookie, ec_params)
        else:
            raise (TypeError, 'protocol invalid:%s' % protocol)

        return data

    @staticmethod
    def mk_send_data(params):
        '''
        返回datapair:ec_params
        '''

        if isinstance(params, basestring):
            return params

        ec_params = urllib.urlencode(params)

        return ec_params

def main():
    api = SNSNetwork('msdktest.qq.com')

if __name__ == '__main__':
    socket.setdefaulttimeout(4)
    main()

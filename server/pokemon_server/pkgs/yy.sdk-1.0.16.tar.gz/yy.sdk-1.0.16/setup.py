#!/usr/bin/env python
from distutils.core import setup

setup(
    name='yy.sdk',
    version='1.0.16',
    install_requires=('bottle', 'ujson', 'M2Crypto'),
    packages=[ 'yy.sdk',
               'HJSDK',
               'msdks', 'msdks/lib',
              ],
)

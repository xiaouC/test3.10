# -*- coding: utf-8 -*-
"""
    yy.sdk.login
    ~~~~~~~~~~~~

    第三方 SDK 验证登录

    :copyright: (c) Yunyuegame
"""
import logging
logger = logging.getLogger('sdk')

import sys
import random
import time
from datetime import datetime
import urllib
import urllib2
import urlparse
import ujson as json
from hashlib import md5, sha1
import hmac
import socket
import struct

from HJSDK import auth, config
from HJSDK.config import set_config as update_hj_config

from urllib3 import PoolManager
sdk_poolmanager = PoolManager(num_pools=10)


def check_login_91(request, cfg, sid, uin):
    args = {
        'AppId': cfg['AppId'],
        'Act': '4',
        'Uin': uin,
        'SessionId': sid,
    }
    msg = '{AppId}{Act}{Uin}{SessionId}{AppKey}'.format(AppKey=cfg['AppKey'], **args)
    args['Sign'] = md5(msg).hexdigest()
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields=args)
    if rsp.status == 200:
        try:
            data = json.loads(rsp.data)
        except ValueError:
            logger.error('[sdk 91]decode check login response failed %s', rsp.data)
            return False
        if data.get('ErrorCode') != '1':
            logger.error('[sdk 91]check login status failed %s %s',
                         data.get('ErrorCode'), data.get('ErrorDesc'))
            return False
        return True
    else:
        return False


def check_login_dl(request, cfg, sid, uin):
    dlinfo = cfg
    args = {
        'app_id': dlinfo['AppId'],
        'mid': uin,
        'token': sid,
        'sig': md5(sid + '|' + dlinfo['AppKey']).hexdigest(),
    }
    rsp = sdk_poolmanager.request('GET', dlinfo['loginurl'], fields=args)
    if rsp.status != 200:
        logger.error('[sdk dl]response status error %d', rsp.status)
        return False
    data = json.loads(rsp.data)
    if data.get('error_code', 0) != 0:
        logger.error('[sdk dl]response error %s', data)
        return False

    return True


def check_login_gf(request, cfg, sid, uin):
    url = cfg['loginurl']
    rsp = urllib.urlopen(url + '?' + 'token=%s' % sid)
    if rsp.code != 200:
        logger.error('[sdk gf]response status error %d', rsp.code)
        return False
    data = json.loads(rsp.read())
    if data.get('resultCode', -2) != 1:
        logger.error('[sdk df]response error %s', data)
        return False
    return True


def check_login_xiaomi(request, cfg, sid, uin):
    url = cfg['loginurl']
    args = {
        'appId': cfg['appId'],
        'session': sid,
        'uid': uin,
    }
    sign = hmac.new(cfg['appSecret'],
                    '&'.join(['%s=%s' % (k, v) for k, v in sorted(args.items())]),
                    digestmod=sha1).hexdigest()
    args['signature'] = sign
    sargs = '&'.join(['%s=%s' % (k, v) for k, v in sorted(args.items())])
    rsp = urllib.urlopen(url + '?' + sargs)
    if rsp.code != 200:
        logger.error('[sdk mi]response status error %d', rsp.status)
        return False
    data = json.loads(rsp.read())
    if data.get(u'errcode', 0) != 200:
        logger.error('[sdk mi]response error %s', data)
        return False
    return True


def check_login_pp(request, cfg, sid, uin):
    sock = socket.socket()
    sock.connect(cfg['addr'])

    bs = []
    for i in range(len(sid) / 2):
        bs.append(chr(int(sid[i * 2:i * 2 + 2], 16)))

    s = ''.join(bs)
    data = struct.pack('<II16s', 24, 0xaa000022, s)
    sock.sendall(data)
    fp = sock.makefile('r')
    l, cmd, status = struct.unpack('<III', fp.read(12))
    body = fp.read(l - 12)
    if status != 0:
        logger.error('[sdk pp]response error %s', status)
        return False

    username = body[:body.find('\0')]
    return username


def check_login_itools(request, cfg, sid, uin):
    appId = cfg['appId']
    verifyurl = cfg['loginurl']
    sign = 'appid=%s&sessionid=%s' % (appId, sid)
    otherurl = 'appid=%s&sessionid=%s&sign=%s' % (appId, sid, md5(sign).hexdigest())
    verifyurl += '&' + otherurl
    rep = urllib2.urlopen(verifyurl)
    rs = json.loads(rep.read())
    if rs['status'] != 'success':
        return False
    return True


def check_login_ourpalm(request, cfg, sid, uin):
    payload = {'jsonStr': json.dumps({'interfaceId': '0002', 'tokenId': sid})}
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields=payload)
    if rsp.status != 200:
        logger.error('[sdk ourpalm]response status error %d', rsp.status)
        return False
    data = json.loads(rsp.data)
    if int(data.get('status', 1)) != 0:
        return False
    return True, data['Username']


def check_login_uc(request, cfg, sid, uin):
    sign = md5('sid=' + sid + cfg['AppKey']).hexdigest()
    args = {
        'id': int(time.time()),
        'service': 'ucid.user.sidInfo',
        'game': cfg['game'],
        'data': {
            'sid': sid,
        },
        'sign': sign,
    }
    rsp = sdk_poolmanager.urlopen('POST', cfg['loginurl'], body=json.dumps(args), assert_same_host=False)
    if rsp.status != 200:
        logger.error('[sdk uc]response status error %d', rsp.status)
        return False
    try:
        data = json.loads(rsp.data)
    except ValueError:
        logger.error('[sdk uc]decode check login response failed %s', rsp.data)
        return False
    if data['state']['code'] != 1:
        logger.error('[sdk uc]send args %s return failed msg %s', args, data)
        return False
    ucid = str(data['data'].get('accountId', ""))
    return ucid


def check_login_xy(request, cfg, sid, uin):
    """XY 助手"""
    args = {
        'appid': cfg['appid'],
        'uid': uin,
        'token': sid,
    }
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], fields=args)
    if rsp.status != 200:
        logger.error('[sdk xy]response status error %d', rsp.status)
        return False
    try:
        data = json.loads(rsp.data)
    except ValueError:
        logger.error('[sdk xy]decode check login response failed %s', rsp.data)
        return False
    if data['ret'] != 0:
        logger.error('[sdk xy]send args %s return failed msg %s', args, data)
        return False
    return True


def check_login_tb(request, cfg, sid, uin):
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields={'k': sid})
    if rsp.status == 200:
        try:
            data = json.loads(rsp.data)
        except ValueError:
            logger.error('[sdk tb]decode check login response failed %s', data)
            return False
        if data <= 0:
            logger.error('[sdk tb]check login status failed %s', data)
            return False
        return True
    return False


def check_login_ky(request, cfg, sid, uin):
    m = md5(cfg['AppKey'])
    m.update(sid)
    sign = m.hexdigest()
    params = {'tokenKey': sid, 'sign': sign}
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields=params)
    if rsp.status == 200:
        try:
            data = json.loads(rsp.data)
        except ValueError:
            logger.error('[sdk ky]decode check login response failed %s', data)
            return False
        if data.get('code', -1) is not 0:
            logger.error('[sdk ky]check login status failed %s', data)
            return False
        return data["data"]["guid"]
    return False


def check_login_as(request, cfg, sid, uin):
    params = {'token': sid}
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], fields=params)
    if rsp.status == 200:
        try:
            data = json.loads(rsp.data)
        except ValueError:
            logger.error('[sdk as]decode check login response failed %s', data)
            return False
        if data.get('status', -1) is not 0:
            logger.error('[sdk as]check login status failed %s', data)
            return False
        return data["username"]
    return False


def check_login_iiapple(request, cfg, sid, uin):
    params = {'user_id': uin, 'session': sid, 'game_id': cfg['gameKey']}
    message = '&'.join(['{}={}'.format(k, params[k]) for k in sorted(params.keys())])
    logger.debug(message)
    signature = md5(md5(message).hexdigest() + cfg['secretKey']).hexdigest()
    params['_sign'] = signature
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields=params)
    if rsp.status == 200:
        try:
            data = json.loads(rsp.data)
            logger.debug(data)
        except ValueError:
            logger.error('[sdk iiapple]decode check login response failed %s', data)
            return False
        if data.get('status', 0) is not 1:
            logger.error('[sdk iiapple]check login status failed %s', data)
            return False
        return True
    return False


def check_login_lj(request, cfg, sdkInfo):
    '棱镜特殊处理'
    path = cfg["loginurl"]
    qs = "userId=%s&channel=%s&token=%s&productCode=%s" % (
        sdkInfo.userId, sdkInfo.channelID, sdkInfo.token, sdkInfo.productCode)
    uri = "?".join([path, qs])
    rsp = sdk_poolmanager.urlopen('GET', uri)
    if rsp.status != 200:
        logger.error('[sdk lj]response status error %d', rsp.status)
        return False
    return json.loads(rsp.data)


def check_login_c360(request, cfg, sid, uin):
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields={'access_token': sid})
    if rsp.status != 200:
        logger.error('[sdk c360]response status error %d', rsp.status)
        return False
    return json.loads(rsp.data)['id']


def check_login_wdj(request, cfg, sid, uin):
    fields = {'uid': uin, 'token': sid, 'appkey_id': cfg['appkey']}
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields=fields)
    if rsp.status != 200:
        logger.error('[sdk wdj]response status error %d', rsp.status)
        return False
    if rsp.data != 'true':
        logger.error('[sdk wdj]response content is not true %s', rsp.data)
        return False

    return True


def check_login_baidu(request, cfg, sid, uin):
    sign = md5(cfg['appid'] + sid + cfg['secretkey']).hexdigest()
    fields = {'AppID': cfg['appid'], 'AccessToken': sid, 'Sign': sign}
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], fields)
    if rsp.status != 200:
        logger.error('[sdk baidu]response status error %d', rsp.status)
        return False
    msg = json.loads(rsp.data)
    content = urllib.unquote(msg['Content'])
    rsp_sign = md5(cfg['appid'] + str(msg['ResultCode']) + content + cfg['secretkey']).hexdigest()
    if msg['Sign'] != rsp_sign:
        logger.error('[sdk baidu]response sign mismatch %s %s', msg['Sign'], rsp_sign)
        return False
    return str(json.loads(content.decode('base64'))['UID'])


def check_login_anzhi(request, cfg, sid, uin):
    sign = (cfg['appkey'] + sid + cfg['appsecret']).encode('base64').replace('\n', '')
    fields = {
        'time': datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3],
        'appkey': cfg['appkey'],
        'sid': sid,
        'sign': sign,
    }
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], fields)

    if rsp.status != 200:
        logger.error('[sdk anzhi]response status error %d', rsp.status)
        return False

    data = json.loads(rsp.data.replace("'", '"'))
    if data['sc'] != "1":
        logger.error('[sdk anzhi]response error %s', rsp.data)
        return False

    return str(json.loads(data['msg'].decode('base64').replace("'", '"'))['uid'])


def check_login_oppo(request, cfg, sid, uin):
    tokens = urlparse.parse_qs(sid)
    fields = {
        'oauth_consumer_key': cfg['appkey'],
        'oauth_nonce': random.randint(0, sys.maxint),
        'oauth_signature_method': 'HMAC-SHA1',
        'oauth_token': tokens['oauth_token'][0],
        'oauth_timestamp': int(time.time()),
        'oauth_version': '1.0',
    }
    args = sorted(fields.items())
    tosign = '&'.join(['POST', urllib.quote_plus(cfg['loginurl']), urllib.urlencode(args)])
    key = '&'.join([cfg['secretkey'], tokens['oauth_token_secret'][0]])
    sign = urllib.quote_plus(hmac.new(key, tosign, digestmod=sha1).digest().encode('base64'))
    header = 'OAuth ' + ','.join('%s="%s"' % (k, v) for k, v in args) + (',oauth_signature=%s' % sign)
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], {}, headers={'Authorization': header})
    if rsp.status != 200:
        logger.error('[sdk oppo]response status error %d', rsp.status)
        return False

    if 'errorCode' in rsp.data:
        logger.error('[sdk oppo]response invalid %s', rsp.data)
        return False

    data = json.loads(rsp.data)
    try:
        return data['BriefUser']['id']
    except KeyError:
        logger.error('[sdk oppo]response error %s', rsp.data)
        return False


def check_login_wanka(request, cfg, sid, uin):
    update_hj_config(cfg)
    channel_instance = auth.get_channel_instance(sid)
    if channel_instance:
        retData = channel_instance.invoke_service()
        if 'errMsg' in retData:
            logger.error('[sdk wanka]response invalid %s', retData)
            return False
        return retData['open_id'], json.dumps(retData)


def check_login_hm(request, cfg, sid, uin):
    params = {'t': sid, 'appid': cfg['appid']}
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], params)

    if rsp.status != 200:
        logger.error('[sdk hm]response status error %d', rsp.status)
        return False

    if rsp.data != "success":
        logger.error('[sdk hm]response error %s', rsp.data)
        return False

    return True


def check_login_qq(request, cfg, sid, uin):
    get_args = {
        'timestamp': str(int(time.time())),
        'appid': cfg['qq_appid'],
        'openid': uin,
        'encode': 1,
        'conn': 1,
    }
    get_args['sig'] = md5(cfg['qq_appkey'] + get_args['timestamp']).hexdigest()
    args = {
        "appid": int(cfg['qq_appid']),
        "openid": uin,
        "openkey": sid,
        "userip": request.remote_route[0],
    }

    url = cfg['qq_loginurl'] + '?' + urllib.urlencode(get_args)
    rsp = sdk_poolmanager.urlopen('POST', url, body=json.dumps(args))
    if rsp.status != 200:
        logger.error('[sdk qq]response status error %d %s', rsp.status, rsp.data)
        return False

    data = json.loads(rsp.data)
    if data['ret'] != 0:
        logger.error('[sdk qq]verify fail %s', rsp.data)
        return False

    return True


def check_login_weixin(request, cfg, sid, uin):
    get_args = {
        'timestamp': str(int(time.time())),
        'appid': cfg['weixin_appid'],
        'openid': uin,
        'encode': 1,
        'conn': 1,
    }
    get_args['sig'] = md5(cfg['weixin_appkey'] + get_args['timestamp']).hexdigest()
    url = cfg['weixin_loginurl'] + '?' + urllib.urlencode(get_args)

    args = {
        "accessToken": sid,
        'openid': uin,
    }
    rsp = sdk_poolmanager.urlopen('POST', url, body=json.dumps(args))
    if rsp.status != 200:
        logger.error('[sdk weixin]response status error %d %s', rsp.status, rsp.data)
        return False

    data = json.loads(rsp.data)
    if data['ret'] != 0:
        logger.error('[sdk weixin]verify fail %s', rsp.data)
        return False

    return True


def check_login_yyb(request, cfg, sid, uin):
    'sid: '
    data = json.loads(sid)
    if data['type'] == 'weixin':
        return check_login_weixin(request, cfg, data['token'], uin)
    elif data['type'] == 'qq':
        return check_login_qq(request, cfg, data['token'], uin)
    else:
        logger.error('[sdk yyb]response request type %s', data)
        return False


def check_login_gfan(request, cfg, sid, uin):
    rsp = sdk_poolmanager.urlopen('GET', cfg['loginurl'] + '?' + urllib.urlencode({
        'token': sid,
    }))
    if rsp.status != 200:
        logger.error('[sdk gfan]response status error %d %s', rsp.status, rsp.data)
        return False

    data = json.loads(rsp.data)
    if data['resultCode'] != 1:
        logger.error('[sdk gfan]login fail %s', rsp.data)
        return False

    return str(data['uid'])


def check_login_m4399(request, cfg, sid, uin):
    rsp = sdk_poolmanager.urlopen('GET', cfg['loginurl'] + '?' + urllib.urlencode({
        'state': sid,
        'uid': uin,
    }))
    if rsp.status != 200:
        logger.error('[sdk m4399]response status error %d %s', rsp.status, rsp.data)
        return False

    data = json.loads(rsp.data)
    if int(data['code']) != 100:
        logger.error('[sdk m4399]check login failed %s', rsp.data)
        return False

    return True


def check_login_paojiao(request, cfg, sid, uin):
    rsp = sdk_poolmanager.urlopen('GET', cfg['loginurl'] + '?' + urllib.urlencode({
        'token': sid,
        'appId': cfg['appid'],
    }))
    if rsp.status != 200:
        logger.error('[sdk paojiao]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if int(data['code']) != 1:
        logger.error('[sdk paojiao]check login failed %s', rsp.data)
        return False
    return True


def check_login_pipaw(request, cfg, sid, uin):
    data = json.loads(sid)
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], {
        'appId': cfg['appid'],
        'merchantId': cfg['merchant_id'],
        'merchantAppId': cfg['merchant_app_id'],
        'username': data['username'],
        'sid': data['sid'],
        'time': data['time'],
    })
    if rsp.status != 200:
        logger.error('[sdk pipaw]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if int(data['result']) != 1:
        logger.error('[sdk pipaw]check login failed %s', rsp.data)
        return False
    return data['uid']


def check_login_hwd(request, cfg, sid, uin):
    return True


def check_login_youku(requset, cfg, sid, uin):
    tosign = 'appkey=%s&sessionid=%s' % (cfg['appkey'], sid)
    signed = hmac.new(cfg['paykey'],
                      tosign,
                      digestmod=md5).hexdigest()
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], {
        'sessionid': sid,
        'appkey': cfg['appkey'],
        'sign': signed,
    })
    if rsp.status != 200:
        logger.error('[sdk youku]response status error %d %s', rsp.status, rsp.data)
        return False
    if not rsp.data:
        logger.error('[sdk youku]response is empty, session is expired')
        return False
    data = json.loads(rsp.data)
    if data['status'] != 'success':
        logger.error('[sdk youku]check login failed %s', rsp.data)
        return False
    return str(data['uid'])


def check_login_yyh(request, cfg, sid, uin):
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], {
        'ticket': sid,
        'app_id': cfg['appid'],
        'app_key': cfg['appkey'],
    }, encode_multipart=False)
    if rsp.status != 200:
        logger.error('[sdk yyh]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if int(data['status']) != 0:
        logger.error('[sdk yyh]check login failed %s', rsp.data)
        return False
    return data['data']['user_name']


def check_login_egame(request, cfg, sid, uin):
    args = {
        'client_id': cfg['client_id'],
        'client_secret': cfg['client_secret'],
        'code': sid,
        'grant_type': 'authorization_code',
    }
    args.update({
        'client_id': cfg['client_id'],
        'sign_method': 'MD5',
        'version': '1.0',
        'timestamp': str(int(time.time())),
    })
    fields = ['client_id', 'version', 'sign_method', 'client_secret', 'timestamp', 'code', 'grant_type']
    args['sign_sort'] = '&'.join(fields)
    args['signature'] = md5(''.join(args[f] for f in fields)).hexdigest()
    rsp = sdk_poolmanager.request('POST', cfg['loginurl'], args, encode_multipart=False)
    if rsp.status != 200:
        logger.error('[sdk egame]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if data.get('error'):
        logger.error('[sdk egame]check login failed %s', rsp.data)
        return False
    return str(data['user_id'])


def check_login_kugou(request, cfg, sid, uin):
    url = cfg['loginurl'] + '&token=' + sid
    rsp = sdk_poolmanager.request('GET', url)
    if rsp.status != 200:
        logger.error('[sdk kugou]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if int(data['response']['code']) != 0:
        logger.error('[sdk kugou]check login failed %s', rsp.data)
        return False
    return True


def check_login_downjoy(request, cfg, sid, uin):
    sig = md5('|'.join([cfg['appid'], cfg['appkey'], sid, uin])).hexdigest()
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], {
        'appid': cfg['appid'],
        'umid': uin,
        'token': sid,
        'sig': sig,
    })
    if rsp.status != 200:
        logger.error('[sdk downjoy]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if data['msg_code'] == 2000 and data['valid'] == '1':
        return True
    else:
        logger.error('[sdk downjoy]check login failed %s', rsp.data)
        return False


def check_login_pps(request, cfg, sid, uin):
    d = json.loads(sid)
    if d['token'] != md5('&'.join([uin, d['time'], cfg['loginkey']])).hexdigest():
        logger.error('[sdk pps]check login failed %s %s', sid, uin)
        return False
    return True


def check_login_mzw(request, cfg, sid, uin):
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], {
        'token': sid,
        'appkey': cfg['appkey'],
    })
    if rsp.status != 200:
        logger.error('[sdk mzw]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if data['code'] == '1':
        return data['user']['uid']
    else:
        logger.error('[sdk mzw]check login failed %s', rsp.data)
        return False


def check_login_pptv(request, cfg, sid, uin):
    d = json.loads(sid)
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], {
        'type': 'login',
        'sessionid': d['SessionId'],
        'username': d['BindUsrName'],
        'app': 'mobgame',
    })
    if rsp.status != 200:
        logger.error('[sdk pptv]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if data['status'] == 1:
        return True
    else:
        logger.error('[sdk pptv]check login failed %s', rsp.data)
        return False


def check_login_vivo(request, cfg, sid, uin):
    rsp = sdk_poolmanager.request('GET', cfg['loginurl'], {
        'access_token': sid,
    })
    if rsp.status != 200:
        logger.error('[sdk vivo]response status error %d %s', rsp.status, rsp.data)
        return False
    data = json.loads(rsp.data)
    if data.get('stat') in (200, None):
        return data['uid']

    logger.error('[sdk vivo]login check failed %s', rsp.data)
    return False


if __name__ == '__main__':
    param = {
        'channel': 'coolpad',
        'auth_code': 'f10ba57a006ce4f6ecc5dd93946e4b73',       #auth_code过期时间300秒，就不提供测试数据了
        'access_token': '',
        'token_secret': ''
    }
    print check_login_wanka(None, json.dumps(param), None)

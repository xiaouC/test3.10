# -*- coding: utf-8 -*-
"""
    yy.sdk.pay
    ~~~~~~~~~~

    支付回调

    :copyright: (c) Yunyuegame
"""
import logging
logger = logging.getLogger('sdk')

import os
import time
import urllib
import urlparse
import hashlib
from six.moves import http_cookies
import ujson as json
from bottle import HTTPResponse
from hashlib import md5, sha1
import hmac
from M2Crypto.EVP import Cipher, PKey
from M2Crypto import BIO, RSA
from cStringIO import StringIO
import base64
from xml.dom.minidom import parseString

from HJSDK import notify, createOrder
from HJSDK.config import set_config as update_hj_config
from msdks.api import Api
from msdks.payments import get_balance, pay_m, cancel_pay_m

MAX_BODY = 2048
SUCCESS = "SUCCESS"
FAILURE = "FAILURE"


def JSONResponse(payload):
    headers = {'content-type': 'application/json; charset=utf8'}
    return HTTPResponse(json.dumps(payload), headers=headers)


def rsa_verify(pubkey, content, signature, digesttype='sha1'):
    bio = BIO.MemoryBuffer(pubkey)
    rsa = RSA.load_pub_key_bio(bio)
    pubkey = PKey()
    pubkey.reset_context(md=digesttype)
    pubkey.assign_rsa(rsa)
    pubkey.verify_init()
    pubkey.verify_update(content)
    return pubkey.verify_final(signature) == 1


# {{{ 筑巢
def sdk_zcgame_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    signature = request.params['sign'].decode('base64')
    msg = '&'.join(['{}={}'.format(k, request.params[k])
                    for k in sorted(request.params.keys()) if k != 'sign'])

    bio = BIO.MemoryBuffer(cfg['rsa_public_key'])
    key = RSA.load_pub_key_bio(bio)
    if key.verify(hashlib.sha1(msg).digest(), signature):
        result = pay(
            request.worldID, request.params['user_id'], request.transaction_id,
            int(max(1, int(request.params['product_price']) / 100)),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return 'success'
    else:
        return 'invalid signature'
# }}}


# {{{ iapppay
def int2byte(n):
    buf = []
    while n:
        buf.append(chr(n % 256))
        n /= 256
    buf.reverse()
    return ''.join(buf)


def validate_iapppay_sign(sign, trans, key):
    key3 = key.decode('base64')[40:].decode('base64')
    private_key, mod_key = key3.split('+')

    # keylen = 64
    # bln = keylen * 2 - 1
    # bitlen = math.ceil(bln / 8)
    arr = sign.strip().split(' ')
    data = ''
    for v in arr:
        v = int(v, 16)
        v = pow(v, int(private_key), int(mod_key))
        v = int2byte(v)
        data += v

    data = data.strip()
    return data == md5(trans).hexdigest()


def sdk_iapppay_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY)
    data = request.params['transdata']
    sign = request.params['sign']
    appkey = cfg['appkey']
    # check sign
    if not validate_iapppay_sign(sign, data, appkey):
        logger.error('[iapppay] verify sign failed')
        return FAILURE
    data = json.loads(data)
    if data['result'] != 0:
        logger.error('[iapppay] pay result fail')
        return FAILURE
    worldID, roleID = data['cpprivate'].split('_', 1)
    pay(int(worldID), int(roleID),
        data['exorderno'], float(data['money']) / 100,
        rawmsg, sdktype)
    return SUCCESS
# }}}


# {{{ PP 助手
def sdk_pp_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    params = dict(request.params)

    bio = BIO.MemoryBuffer(cfg['rsa_public_key'])
    ctx = RSA.load_pub_key_bio(bio)
    raw = ctx.public_decrypt(params['sign'].decode('base64'), RSA.pkcs1_padding)
    data = json.loads(raw)

    if data and data['status'] in (0, 1):
        (giftID, worldID, entityID) = map(int, data['roleid'].split('_'))
        pay(worldID, entityID,
            data['billno'], int(float(data['amount'])),
            json.dumps(data), sdktype)
        return 'success'
    else:
        return 'fail'
# }}}


# {{{ itools
def sdk_itools_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    signature = request.params.get('sign')
    notify_data = request.params.get('notify_data')

    bio = BIO.MemoryBuffer(cfg['rsa_public_key'])
    b64string = notify_data.decode('base64')
    rsa_itools = RSA.load_pub_key_bio(bio)
    rsa_max_length = 128
    data = []
    slength = len(b64string)
    startIndex = 0
    index = 0
    while (slength > index):
        if index + rsa_max_length < slength:
            index += rsa_max_length
        else:
            index = slength
        data.append(b64string[startIndex:index])
        startIndex = index

    ctxt = ""
    for i in range(len(data)):
        ctxt += rsa_itools.public_decrypt(data[i], RSA.pkcs1_padding)

    jsondata = json.loads(ctxt)
    b64signature = signature.decode('base64')
    datasha = sha1(ctxt).digest()
    if not rsa_itools.verify(datasha, b64signature):
        return 'fail'

    transaction_id = jsondata['order_id_com']
    # worldID_id_entityID_transaction_id
    (giftID, worldID, entityID, transaction_id) = jsondata['order_id_com'].split('_')

    pay(int(worldID), int(entityID),
        transaction_id, float(jsondata['amount']),
        rawmsg, sdktype)
    return 'success'
# }}}


# {{{ lj
def sdk_lj_callback(cfg, request, sdktype, pay):
    orderId = request.GET['orderId']
    price = request.GET['price']
    # channelCode = request.GET['channelCode']
    callbackInfo = request.GET['callbackInfo']
    sign = request.GET['sign']
    # channelLabel = request.GET['channelLabel']
    productSecret = cfg["privateKey"]
    m = md5()
    m.update(orderId)
    m.update(price)
    m.update(callbackInfo)
    m.update(productSecret)
    if m.hexdigest() != sign:
        logger.error("params: %r", dict(request.GET))
        logger.error("validate lj pay_callback fail")
        return FAILURE
    params = callbackInfo.decode('base64')
    (worldID, giftID, entityID, order_id) = params.split("_")
    result = pay(
        int(worldID), int(entityID),
        order_id, int(price) / 100,
        json.dumps(dict(request.GET)), sdktype)
    if result == FAILURE:
        return "duplicate"
    elif result == SUCCESS:
        return "success"
    logger.error("lj pay_callback result is %r", result)
    return "failure"
# }}}


# {{{ UC
def sdk_uc_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    msg = json.loads(rawmsg)
    data = msg['data']
    tosign = ''.join(sorted('%s=%s' % (k, v) for k, v in data.items()))
    if md5(tosign.encode('utf-8') + cfg['AppKey']).hexdigest() != msg['sign']:
        logger.error("uc fail to verify signature")
        return "FAILURE"

    if data['orderStatus'] != 'S':
        logger.error("uc order status is not valid")
        return "SUCCESS"

    worldID, entityID = data['callbackInfo'].split('_')
    result = pay(
        worldID, entityID, data['cpOrderId'],
        int(float(data['amount'])),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'SUCCESS'
    else:
        logger.error("uc pay_callback fail")
        return "FAILURE"
# }}}


# {{{ 爱思助手
def sdk_as_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    signature = request.params.get('sign')
    params = dict(request.params)

    bio = BIO.MemoryBuffer(cfg['rsa_public_key'])
    b64string = signature.decode('base64')
    pkey = RSA.load_pub_key_bio(bio)
    rsa_max_length = 128
    data = []
    slength = len(b64string)
    startIndex = 0
    index = 0
    while (slength > index):
        if index + rsa_max_length < slength:
            index += rsa_max_length
        else:
            index = slength
        data.append(b64string[startIndex:index])
        startIndex = index

    ctxt = ""
    for i in range(len(data)):
        ctxt += pkey.public_decrypt(data[i], RSA.pkcs1_padding)

    logger.debug(params)
    data = dict([(k, v[0]) for k, v in urlparse.parse_qs(ctxt).items()])
    logger.debug('data: {}'.format(data))
    if data['billno'] == params['billno'] \
            and data['amount'] == params['amount'] \
            and data['status'] == params['status']:
        (giftID, transaction_id) = data['billno'].split('_')
        result = pay(
            int(params['zone']), int(params['role']), transaction_id,
            float(request.params['amount']),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return 'success'
    else:
        return 'fail'
# }}}


# {{{ 快用
def sdk_ky_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    bio = BIO.MemoryBuffer(cfg['rsa_public_key'])
    rsa = RSA.load_pub_key_bio(bio)

    params = dict(request.params)
    data = urlparse.parse_qs(rsa.public_decrypt(params['notify_data'].decode('base64'), RSA.pkcs1_padding))
    logger.info(data)
    payresult = int(data['payresult'][0])

    if data['dealseq'][0] != params['dealseq']:
        logger.error('[ky]dealseq is not consistence')
        return 'fail'

    (giftID, worldID, entityID, orderID) = params['dealseq'].split('_')
    if payresult == 0:
        result = pay(
            int(worldID), int(entityID), orderID,
            float(data['fee'][0]),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return 'success'
    else:
        logger.error('[ky] pay result: %s (orderId:%s)', payresult, orderID)
        return 'fail'
# }}}


# {{{ i苹果
def sdk_iiapple_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    message = '&'.join([urllib.urlencode({k: request.params[k]})
                        for k in sorted(request.params.keys()) if k != '_sign'])
    logger.debug(message)
    signature = md5(md5(message).hexdigest() + cfg['secretKey']).hexdigest()
    if signature == request.params['_sign']:
        (giftID, worldID, entityID, orderID) = request.params['gameExtend'].split('_')
        result = pay(
            int(worldID), int(entityID), orderID,
            float(request.params['amount']),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return JSONResponse(dict(status=0, transIDO=int(request.params['transaction'])))
        return JSONResponse(dict(status=0, transIDO=int(request.params['transaction'])))
    else:
        return JSONResponse(dict(status=1, transIDO=int(request.params['transaction'])))

# }}}


# {{{ 同步推
def sdk_tb_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    params = dict(request.params)
    params['partner'] = cfg['appid']
    params['key'] = cfg['appkey']
    params.setdefault('paydes', '')
    message = 'source={source}&trade_no={trade_no}&amount={amount}' \
              '&partner={partner}&paydes={paydes}&debug={debug}' \
              '&tborder={tborder}&key={key}'.format(**params)
    logger.debug(message)
    signature = md5(message).hexdigest()
    if signature == request.params['sign']:
        (giftID, worldID, entityID, orderID) = request.params['trade_no'].split('_')
        result = pay(
            int(worldID), int(entityID), orderID,
            float(request.params['amount']) / 100,
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return JSONResponse(dict(status='success'))
    else:
        return JSONResponse(dict(status='fail'))
# }}}


# {{{ XY 助手
def sdk_xy_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    params = dict(request.params)
    message = '&'.join([urllib.urlencode({k: params[k]})
                        for k in sorted(params.keys()) if k not in ('sign', 'sig')])
    # logger.debug(message)
    signature = md5(cfg['appkey'] + message).hexdigest()
    if signature == request.params['sign']:
        (giftID, worldID, entityID, orderID) = request.params['extra'].split('_')
        result = pay(
            int(worldID), int(entityID), orderID,
            float(request.params['amount']),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return JSONResponse(dict(ret=0, msg='success'))
    else:
        logger.debug(params)
        return JSONResponse(dict(status=8, msg='fail'))
# }}}


# {{{ 小米
def sdk_xiaomi_callback(cfg, request, sdktype, pay):
    '''
    TODO 白名单
    42.62.48.246
    223.202.68.237
    42.62.103.0/26（42.62.103.1 ~ 42.62.103.62）
    120.134.34.0/26（120.134.34.1 ~ 120.134.34.62）
    '''
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    params = dict(request.params)
    signature = params.pop('signature')
    tosign = '&'.join('%s=%s' % (k, v) for k, v in sorted(params.items()))
    sign = hmac.new(cfg['appSecret'],
                    tosign,
                    digestmod=sha1).hexdigest()
    if sign != signature:
        # fail
        logger.error('signature mismatch %s != %s, tosign: %s', sign, signature, tosign)
        return JSONResponse({'errcode': 1525})
    worldID, entityID = params['cpUserInfo'].split('_')
    result = pay(
        int(worldID), int(entityID), params['cpOrderId'],
        float(params['payFee']) / 100,
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return JSONResponse({'errcode': 200})
    else:
        return JSONResponse({'errcode': 1000, 'errMsg': u'发货失败'})
# }}}


# {{{ 豌豆荚
def sdk_wdj_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    if not rsa_verify(cfg['rsa_public_key'], request.params['content'], request.params['sign'].decode('base64')):
        return 'verify signature failed'

    data = json.loads(request.params['content'])
    orderID, worldID, entityID = data['out_trade_no'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(data['money']) / 100,
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'success'
    else:
        return 'fail'
# }}}


# {{{ 百度
def baidu_response(cfg, errcode, errmsg=''):
    sign = md5(cfg['appid']+str(errcode)+cfg['secretkey']).hexdigest()
    return JSONResponse({
        'AppID': cfg['appid'],
        'sign': sign,
        'ResultCode': errcode,
        'ResultMsg': errmsg,
    })


def sdk_baidu_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    sign = md5(cfg['appid'] + request.params['OrderSerial'] + request.params['CooperatorOrderSerial'] +
               request.params['Content'] +
               cfg['secretkey']).hexdigest()
    if sign != request.params['Sign']:
        return baidu_response(cfg, 2, 'failed to verify signature')

    data = json.loads(request.params['Content'].decode('base64'))

    if data['OrderStatus'] != 1:
        return baidu_response(cfg, 3, 'invalid order status')

    worldID, entityID = data['ExtInfo'].split('_')

    result = pay(
        int(worldID), int(entityID), request.params['CooperatorOrderSerial'],
        float(data['OrderMoney']),
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return baidu_response(cfg, 1)
    else:
        return baidu_response(cfg, 4, 'fail to give gold')
# }}}


# {{{ 360
def sdk_c360_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    params = dict(request.params)
    sign = params.pop('sign')
    params.pop('sign_return', None)
    tosign = '#'.join(str(v) for k, v in sorted(params.items())
                      if v not in ('', '0')) + '#' + cfg['appsecret']
    if md5(tosign).hexdigest() != sign:
        return 'failed to verify signature'

    worldID, entityID = request.params['app_ext1'].split('_')
    result = pay(
        int(worldID), int(entityID), request.params['app_order_id'],
        float(request.params['amount']) / 100,
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'ok'
    else:
        return 'fail'
# }}}


# {{{ OPPO
def sdk_oppo_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    fields = ['notifyId', 'partnerOrder', 'productName', 'productDesc', 'price', 'count', 'attach']
    params = dict(request.params)
    tosign = '&'.join('%s=%s' % (f, params[f]) for f in fields)
    if not rsa_verify(cfg['rsa_public_key'], tosign, params['sign'].decode('base64')):
        return urllib.urlencode({'result': 'FAIL', 'resultMsg': 'fail to verify signature'})

    worldID, entityID = params['attach'].split('_')
    result = pay(
        int(worldID), int(entityID), params['partnerOrder'],
        float(params['price']) / 100,
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return urllib.urlencode({'result': 'OK'})
    else:
        return urllib.urlencode({'result': 'FAIL', 'resultMsg': 'fail to give gold'})
# }}}


# {{{ ANZHI
def sdk_anzhi_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    cipher = Cipher(alg='des_ede3_ecb', key=cfg['appsecret'], op=0, iv='\0' * 16)

    signed = request.params['data'].decode('base64')
    data = cipher.update(signed) + cipher.final()
    data = json.loads(data)

    if int(data['code']) != 1:
        logger.error('[anzhi] invalid order status %s', data)
        return 'success'

    worldID, entityID, orderID = data['cpInfo'].split('_', 2)

    result = pay(
        int(worldID), int(entityID), orderID.replace('_', '-'),
        float(data['payAmount']) / 100,
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'success'
    else:
        return 'fail'

# }}}


# {{{ 硬核
def sdk_wanka_callback(cfg, request, sdktype, pay, channel):
    update_hj_config(cfg)

    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    channel_instance = notify.get_channel_instance(channel)

    if channel_instance:
        retData = channel_instance.invoke_service(request.forms, request.query)
        if retData and retData['paySuccess'] == 1:
            worldID, entityID = retData['cpPrivateInfo'].split('_')
            result = pay(
                int(worldID), int(entityID), retData['myOrderNo'],
                float(retData['money']) / 100,
                rawmsg, sdktype=sdktype)

            if 'success' in result:
                return channel_instance.send_response()
            else:
                return channel_instance.send_response('fail')
        else:
            return channel_instance.send_response('fail')


def sdk_wanka_create_order(cfg, request):
    update_hj_config(cfg)

    param = dict(request.params)
    channel_instance = createOrder.get_channel_instance(param['returnJson'])

    money = param['amount']
    myOrderID = param['orderid']
    title = param['productName']
    orderDesc = param['description']
    cpinfo = param['cpPrivateInfo']
    retData = channel_instance.invoke_service(money, myOrderID, title, orderDesc, cpinfo)

    assert 'errMsg' not in retData, retData['errMsg']
    return json.dumps(retData)
# }}}


# {{{ 海马
def sdk_hm_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    params = dict(request.params)
    logger.debug(params)
    fields = ('notify_time', 'appid', 'out_trade_no', 'total_fee', 'subject', 'body', 'trade_status')
    message = '&'.join([urllib.urlencode({k: params[k]}) for k in fields]) + cfg['appkey']
    logger.debug(message)
    signature = hashlib.md5(message).hexdigest()

    if signature == request.params['sign']:
        (giftID, worldID, entityID) = request.params['user_param'].split('_')
        result = pay(
            int(worldID), int(entityID), params['out_trade_no'],
            float(params['total_fee']),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return 'success'
    else:
        return 'fail'
# }}}


# {{{ 应用宝
def sdk_yyb_callback(cfg, request, sdktype, pay):
    pass


def encode_cookie_header(args):
    c = http_cookies.SimpleCookie()
    for k, v in args.items():
        c[k] = v
    return c.output()


def sdk_yyb_query_balance(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    api = Api(int(cfg['qq_appid']), cfg['qq_appkey'], [cfg['domain']])
    cookie_args = {
        'session_id': request.params['session_id'],
        'session_type': request.params['session_type'],
        'appip': cfg['qq_appid'],
    }

    worldID, entityID, orderID = request.params['callBackInfo'].split('_')
    zoneid = str(int(worldID) - 299)
    args = {
        'ts': int(time.time()),
        'zoneid': zoneid,
    }
    fields = ['openid', 'openkey', 'pay_token', 'pf', 'pfkey']
    for f in fields:
        args[f] = request.params[f]

    data = get_balance(api, args, cookie_args)
    logger.info('get balance %s %s %s', args, cookie_args, data)
    if data['ret'] != 0 or data['balance'] <= 0:
        # retry
        retry_count = 3 if orderID else 1
        for i in range(retry_count):
            time.sleep(20)
            data = get_balance(api, args, cookie_args)
            logger.info('retry %d get balance %s %s %s', i, args, cookie_args, data)
            if data['ret'] == 0 and data['balance'] > 0:
                break
        else:
            # retry failed
            return 'failed'

    args = {
        'ts': int(time.time()),
        'amt': data['balance'],
        "userip": request.remote_route[0],
        'zoneid': zoneid,
    }
    fields = ['openid', 'openkey', 'pay_token', 'pf', 'pfkey']
    for f in fields:
        args[f] = request.params[f]

    data = pay_m(api, args, cookie_args)
    logger.info('pay_m %s %s %s', args, cookie_args, data)
    if data['ret'] == 0:
        try:
            result = pay(
                int(worldID), int(entityID), orderID,
                float(args['amt']) / 10,
                rawmsg, sdktype=sdktype)
        except:
            logger.exception('do pay failed')
            result = 'fail'

        if 'success' in result:
            return 'success'
        else:
            args['billno'] = data['billno']
            data = cancel_pay_m(api, args, cookie_args)
            if data['ret'] == 0:
                return 'cancelled'
            else:
                logger.error("cancel failed, may lost money %s %s %s", data, args, cookie_args)
                return 'cancel failed'

    return 'failed'

# }}}


def sdk_hwd_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    worldID, entityID = request.POST['ext'].split('_')
    # sign
    tosign = ('ext=%(ext)s&gameOrderId=%(gameOrderId)s&money=%(money)s&orderId=%(orderId)s&productName=%(productName)s&uid=%(uid)s#' % request.POST) + cfg['appkey']
    if request.POST['sign'] != md5(tosign).hexdigest().upper():
        logger.error("[sdk hwd] verify sign failed")
        return 'fail'
    result = pay(
        int(worldID), int(entityID), request.POST['gameOrderId'],
        float(request.POST['money']),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'ok'
    else:
        logger.error("[sdk hwd] pay failed %s", result)
        return 'fail'


def sdk_gfan_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    if request.GET['sign'] != md5(cfg['appid'] + request.GET['time']).hexdigest():
        logger.error("[sdk gfan] verify sign failed")
        return '<response><ErrorCode>0</ErrorCode><ErrorDesc>%s</ErrorDesc></response>' % 'sign verify failed'

    doc = parseString(rawmsg)
    root = doc.getElementsByTagName('response')[0]
    data = {}
    for field in ['order_id', 'appkey', 'cost', 'create_time']:
        data[field] = root.getElementsByTagName(field)[0].childNodes[0].data
    worldID, entityID, orderID = data['order_id'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(data['cost']) / 10,
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return '<response><ErrorCode>1</ErrorCode><ErrorDesc>Success</ErrorDesc></response>'
    else:
        return '<response><ErrorCode>0</ErrorCode><ErrorDesc>%s</ErrorDesc></response>' % 'pay failed'


def sdk_mm_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    doc = parseString(rawmsg)
    root = doc.getElementsByTagName('response')[0]
    data = {}
    for field in ['MD5Sign', 'OrderID', 'ChannelID', 'PayCode']:
        data[field] = root.getElementsByTagName(field)[0].childNodes[0].data

    signed = md5(data['OrderID'] + '#' + data['ChannelID'] + '#' + data['PayCode'] + '#' + cfg['appkey']).hexdigest()
    if signed != data['MD5Sign']:
        logger.error('[mm] verify failed')
        return 'fail'

    worldID, entityID, orderID = data['order_id'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(data['cost']) / 10,
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'success'
    else:
        return 'fail'


def sdk_m4399_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    values = [request.params[f] for f in ['orderid', 'uid', 'money', 'gamemoney',
                                          'serverid', 'mark', 'roleid', 'time']]
    values.insert(5, cfg['appkey'])
    tosign = ''.join(values)

    if request.params['sign'] != md5(tosign).hexdigest():
        logger.error('[sdk m4399] verify failed')
        return JSONResponse({
            "status": 1,
            "code": 'sign_error',
        })

    worldID, orderID = request.params['mark'].split('_')
    money = int(request.params['money'])
    result = pay(
        int(worldID), 0, orderID,
        money,
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return JSONResponse({
            "status": 2,
            "code": None,
            "money": money,
            "gamemoney": money * 10,
            "msg": u"充值成功",
        })
    else:
        logger.error('[sdk m4399] pay failed')
        return JSONResponse({
            "status": 1,
            "code": 'other_error',
        })


def sdk_paojiao_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    fields = ['uid', 'price', 'orderNo', 'remark', 'status', 'subject', 'gameId', 'payTime', 'ext']
    tosign = ''.join('%s=%s' % (f, request.params[f]) for f in fields) + cfg['appkey']
    signed = md5(tosign).hexdigest()

    if request.params['sign'] != signed:
        logger.error('[sdk paojiao] verify failed')
        return 'sign verify fail'

    worldID, entityID, orderID = request.params['ext'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(request.params['price']),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'success'
    else:
        logger.error('[sdk paojiao] pay failed')
        return 'fail'


def sdk_pipaw_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    tosign = '&'.join('%s=%s' % (k, v) for k, v in sorted(request.params.items())
                      if k not in ('sign', 'version')) + cfg['privatekey']
    signed = md5(tosign).hexdigest()

    if request.params['sign'] != signed:
        logger.error('[sdk pipaw] verify failed')
        return 'sign verify fail'

    worldID, entityID = request.params['extraParam'].split('_')
    result = pay(
        int(worldID), int(entityID), request.params['order'],
        float(request.params['amount']),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'OK'
    else:
        logger.error('[sdk pipaw] pay failed')
        return 'fail'


def sdk_youku_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    tosign = '%s?apporderID=%s&price=%s&uid=%s' % (cfg['callbackurl'],
                                                   request.params['apporderID'],
                                                   request.params['price'],
                                                   request.params['uid'])
    signed = hmac.new(cfg['paykey'],
                      tosign,
                      digestmod=md5).hexdigest()
    if request.params['sign'] != signed:
        logger.error('[sdk youku] verify failed')
        return '{"status":"failed", "desc":"数字签名错误"}'

    worldID, entityID = request.params['passthrough'].split('_')
    result = pay(
        int(worldID), int(entityID), request.params['apporderID'],
        float(request.params['price']) / 100,
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return '{"status":"success", "desc":"通知成功"}'
    else:
        logger.error('[sdk youku] pay failed')
        return '{"status":"failed", "desc":"未找到订单"}'


def sdk_yyh_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    if not validate_iapppay_sign(request.params['sign'], request.params['transdata'], cfg['paykey']):
        logger.error('[sdk yyh] verify failed')
        return 'FAILED'

    data = json.loads(request.params['transdata'])
    worldID, entityID = data['cpprivate'].split('_')
    result = pay(
        int(worldID), int(entityID), data['exorderno'],
        float(data['money']) / 100,
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'SUCCESS'
    else:
        logger.error('[sdk yyh] pay failed')
        return 'FAILED'


def sdk_zy_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    tosign = '&'.join('%s=%s' % (k, v) for k, v in sorted(request.params.items())
                      if k != 'Sign') + cfg['privatekey']
    if request.params['Sign'] != md5(tosign).hexdigest():
        logger.error('[sdk zy] verify failed')
        return 'failure'

    worldID, entityID = request.params['Extra'].split('_')

    result = pay(
        int(worldID), int(entityID), request.params['Urecharge_Id'],
        float(request.params['Recharge_Money']),
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'success'
    else:
        logger.error('[sdk zy] pay failed')
        return 'failure'


''' 需要在游戏服务器实现
def sdk_egame_callback(cfg, request, sdktype, pay):
    tpl = '<cp_notify_resp><h_ret>%s</h_ret><cp_order_id>%s</cp_order_id></cp_notify_resp>'
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    if request.params['method'] == 'callback':
        worldID, orderID = request.params['cp_order_id'].split('_')
        fields = ['cp_order_id', 'correlator', 'result_code', 'fee', 'paytype', 'method']
        signed = md5(''.join(request.params[f] for f in fields) + cfg['appkey']).hexdigest()
        if signed != request.params['sign']:
            logger.error('[sdk egame] verify failed')
            return tpl % (-1, orderID)
        result = pay(
            int(worldID), 0, orderID,
            float(request.params['fee']),
            rawmsg, sdktype=sdktype)
        if 'success' in result:
            return tpl % (0, orderID)
        else:
            logger.error('[sdk egame] pay failed')
            return tpl % (-1, orderID)
    else:
        logger.error('[sdk egame] 暂不支持')
        return ''
'''


def sdk_kugou_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string
    fields = ['orderid', 'outorderid', 'amount', 'username', 'status', 'time', 'ext1', 'ext2']
    signed = md5(''.join(request.params[f] for f in fields) + cfg['paykey']).hexdigest()
    if signed != request.params['sign']:
        logger.error('[sdk kugou] verify failed')
        return 'VERIFY FAIL'

    worldID, entityID = request.params['ext1'].split('_')
    result = pay(
        int(worldID), int(entityID), request.params['outorderid'],
        float(request.params['amount']),
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'SUCCESS'
    else:
        logger.error('[sdk kugou] pay failed')
        return 'PAY FAIL'


def sdk_downjoy_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    tosign = 'order=%s&money=%s&mid=%s&time=%s&result=%s&ext=%s&key=%s' % (
        request.params['order'],
        request.params['money'],
        request.params['mid'],
        request.params['time'],
        request.params['result'],
        request.params['ext'],
        cfg['paykey'])
    if md5(tosign).hexdigest() != request.params['signature']:
        logger.error('[sdk downjoy] verify failed')
        return 'failure'

    worldID, entityID, orderID = request.params['ext'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(request.params['money']),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return 'success'
    else:
        logger.error('[sdk downjoy] pay failed %s', result)
        return 'failure'


def sdk_pps_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    tosign = ''.join([request.params['user_id'],
                      request.params['role_id'],
                      request.params['order_id'],
                      request.params['money'],
                      request.params['time'],
                      cfg['paykey']
                      ])
    if md5(tosign).hexdigest() != request.params['sign']:
        logger.error('[sdk pps] verify failed')
        return '{"result":-1,"message":"sign verify failed"}'

    worldID, entityID, orderID = request.params['userData'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(request.params['money']),
        rawmsg, sdktype=sdktype)
    if 'success' in result:
        return '{"result":0,"message":"succes"}'
    else:
        logger.error('[sdk pps] pay failed %s', result)
        return '{"result":-6,"message":"pay failed"}'


def sdk_mzw_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    fields = ['appkey', 'orderID', 'productName', 'productDesc', 'productID', 'money', 'uid', 'extern']
    tosign = ''.join([request.params[f] for f in fields]) + cfg['secret']
    if md5(tosign).hexdigest() != request.params['sign']:
        logger.error('[sdk mzw] verify failed')
        return 'VERIFY FAIL'

    worldID, entityID, orderID = request.params['extern'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(request.params['money']),
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return 'SUCCESS'
    else:
        logger.error('[sdk mzw] pay failed %s', result)
        return 'PAY FAILED'


def sdk_pptv_callback(cfg, request, sdktype, pay):
    rawmsg = request.body.read(MAX_BODY) if request.method == 'POST' else request.query_string

    fields = ['sid', 'username', 'roid', 'oid', 'amount', 'time']
    tosign = ''.join([request.params[f] for f in fields]) + cfg['paykey']
    if md5(tosign).hexdigest() != request.params['sign']:
        logger.error('[sdk pptv] verify failed')
        return '{"code":"4","message":"verify failed"}'

    worldID, entityID, orderID = request.params['extra'].split('_')
    result = pay(
        int(worldID), int(entityID), orderID,
        float(request.params['amount']),
        rawmsg, sdktype=sdktype)

    if 'success' in result:
        return '{"code":"1","message":""}'
    else:
        logger.error('[sdk pptv] pay failed %s', result)
        return '{"code":"2","message":"pay failed"}'

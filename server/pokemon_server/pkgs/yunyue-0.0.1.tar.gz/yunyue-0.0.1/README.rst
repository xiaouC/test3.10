yunyue 共用部分代码
===================

目前包含的功能
--------------

#. 短信发送
#. 推送通知
#. 支付宝


部署
----

supervisord 配置::

    [program:worker]
    command=/home/huangyi/env/bin/python /home/huangyi/env/bin/celery -A backend worker -I celery.task.http --loglevel=info --pool=gevent --autoreload --events
    directory=/home/huangyi/tools/snippets/yunyue/yunyue
    autostart=true
    user=huangyi
    redirect_stderr=True
    stdout_logfile=/tmp/celery.stdout.log

    [program:flower]
    command=/home/huangyi/env/bin/python /home/huangyi/env/bin/celery flower --address=0.0.0.0 --basic_auth=yunyue:yunyueMjlj
    directory=/home/huangyi/tools/snippets/yunyue/yunyue
    autostart=true
    user=huangyi
    redirect_stderr=True
    stdout_logfile=/tmp/celery.flower.stdout.log

    [program:http]
    command=/home/huangyi/env/bin/python /home/huangyi/env/bin/gunicorn -b 192.168.1.167:9000 --access-logfile /home/huangyi/tools/snippets/yunyue/yunyue/access.log rest:app
    directory=/home/huangyi/tools/snippets/yunyue/yunyue
    autostart=true
    user=huangyi
    redirect_stderr=True
    stdout_logfile=/tmp/http.stdout.log

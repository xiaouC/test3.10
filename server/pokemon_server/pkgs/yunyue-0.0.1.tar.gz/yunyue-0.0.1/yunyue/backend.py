#!/usr/bin/env python
# coding=utf-8

"""
后台任务
========
"""

import importlib
from celery import Celery
from celery.registry import tasks

celery = Celery()
celery.config_from_object('celeryconfig')

handlers = [
    ('send_sms', 'sms:SendSMS'),
    ('push_notification', 'common.tasks:PushNotification'),
]

for name, pattern in handlers:
    _module = importlib.import_module(pattern.split(':')[0])
    # tasks.register(getattr(_module, pattern.split(':')[1]))

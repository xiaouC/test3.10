#!/usr/bin/env python
# coding=utf-8

"""
支付宝服务器验证，签名订单
"""

import os
import base64
import binascii
import json
import urllib
import Crypto
from Crypto import Signature
from Crypto.Cipher import PKCS1_v1_5 as PKCS1_v1_5_Cipher
from Crypto.Hash import SHA
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Util import number
from Crypto.Util._number_new import ceil_div
from xml.dom.minidom import parseString

def ensure_utf8(s):
    if isinstance(s, unicode):
        return s.encode('utf8')
    return s

def base64ToString(s):
    try:
        return base64.decodestring(s)
    except binascii.Error, e:
        raise SyntaxError(e)
    except binascii.Incomplete, e:
        raise SyntaxError(e)

def stringToBase64(s):
    return base64.encodestring(s).replace("\n", "")

def getNodesText(nodelist):
    rc = ""
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc = rc + node.data
    return rc

def getNodeTextByTagName(node, tagName):
    selected = node.getElementsByTagName(tagName)
    if selected:
        return getNodesText(selected[0].childNodes)
    else:
        return ""

class AlipayNotifyData(object):
    def __init__(self, trade_no, out_trade_no, buyer_email, total_fee, gmt_payment, trade_status, subject):
        self.trade_no = trade_no
        self.out_trade_no = out_trade_no
        self.buyer_email = buyer_email

        self.total_fee = total_fee
        self.gmt_payment = gmt_payment
        self.trade_status = trade_status
        self.subject = subject

class Alipay(object):
    """
    .. code-block:: python

        alipay = Alipay(private_key='rsa_private_key.pem',
                        public_key='rsa_public_key.pem',
                        alipay_key='alipay_public_key.pem',
                        partner=PARTNER,
                        seller=SELLER)
     """
    def __init__(self, **kwargs):
        self.private_key = open(kwargs['private_key'], 'r').read()
        self.public_key = open(kwargs['public_key'], 'r').read()
        self.alipay_key = open(kwargs['alipay_key'], 'r').read()
        self.partner = kwargs['partner']
        self.seller = kwargs['seller']

    def encrypt(self, msg):
        """msg 必须采用 utf-8 编码"""
        msg = ensure_utf8(msg)

        key = RSA.importKey(self.public_key)
        cipher = PKCS1_v1_5_Cipher.new(key)
        
        modBits = number.size(key.n)
        k = ceil_div(modBits,8) - 28 # 11 # Convert from bits to bytes

        msglen = len(msg)
        msg_encryted = ""
        start_idx = 0
        # 处理过长的加密
        while msglen > 0:
            len1 = min([msglen, k])
            encrypt = cipher.encrypt(msg[start_idx: (start_idx + len1)])
            msg_encryted = msg_encryted + encrypt
            start_idx = start_idx + len1
            msglen = msglen - len1
        return stringToBase64(msg_encryted)

    def decrypt(self, msg):
        """msg 必须采用base64编码，注意: base64 编码的数据经过 urldecode 处理之后，可能不正确，其中的＋会变成' '"""   
        msg = base64ToString(msg)
        key = RSA.importKey(self.private_key)
        cipher = PKCS1_v1_5_Cipher.new(key)
        
        modBits = number.size(key.n)
        k = ceil_div(modBits, 8) # Convert from bits to bytes

        msglen = len(msg)
        msg_encryted = ""
        start_idx = 0
        # 处理过长的加密
        while msglen > 0:
            len1 = min([msglen, k])
            cleartext = cipher.decrypt(msg[start_idx: (start_idx + len1)], "")
            msg_encryted = msg_encryted + cleartext
            start_idx = start_idx + len1
            msglen = msglen - len1
        return msg_encryted

    def sign(self, msg):
        """将 msg 使用 private rsa key 来签名, 返回 base64 编码的字符串"""
        key = RSA.importKey(self.private_key)
        h = SHA.new(msg)
        signer = PKCS1_v1_5.new(key)
        signature = signer.sign(h)
        signature = stringToBase64(signature)
        return signature

    def verify(self, msg, signature):
        """使用 public rsa key 来验证签名是否正确"""
        signature = base64ToString(signature)
        key = RSA.importKey(self.public_key)
        h = SHA.new(msg)
        verifier = PKCS1_v1_5.new(key)
        return verifier.verify(h, signature)

    def verify_with_alipay(self, msg, signature):
        """使用 alipay public rsa key 来验证签名是否正确"""
        signature = base64ToString(signature)
        key = RSA.importKey(self.alipay_key)
        h = SHA.new(msg)
        verifier = PKCS1_v1_5.new(key)
        return verifier.verify(h, signature)

    def parse_notify_data(self, data):
        """通过 minixml 解析异步通知数据"""
        dom = parseString(data)
        notify = dom.getElementsByTagName("notify")[0]
        trade_status = getNodeTextByTagName(notify, "trade_status") 
        # if not (trade_status == "TRADE_FINISHED" or trade_status == "TRADE_SUCCESS"):
        #     return None

        # trade_status = "TRADE_FINISHED"
        trade_no = getNodeTextByTagName(notify, "trade_no")
        out_trade_no = getNodeTextByTagName(notify, "out_trade_no")
        buyer_email = getNodeTextByTagName(notify, "buyer_email")
        total_fee = int(float(getNodeTextByTagName(notify, "total_fee")) * 100 + 0.5)
        
        gmt_payment = getNodeTextByTagName(notify, "gmt_payment")
        subject = getNodeTextByTagName(notify, "subject")

        return AlipayNotifyData(trade_no=trade_no, out_trade_no=out_trade_no, buyer_email=buyer_email, 
                            total_fee=total_fee, gmt_payment=gmt_payment, trade_status=trade_status, 
                            subject=subject)

class AlipayPayload(object):
    def __init__(self, alipay, **kwargs):
        self.alipay = alipay
        self.out_trade_no = kwargs['out_trade_no']
        self.subject = kwargs['subject']
        self.body = kwargs['body']
        self.total_fee = kwargs.get('total_fee', '0.00')
        self.notify_url = kwargs['notify_url']
        self.url_scheme = kwargs['url_scheme']

        params = {'partner': self.alipay.partner, 'seller': self.alipay.seller}
        params.update(kwargs)
        dataString = 'partner="{partner}"&seller="{seller}"&out_trade_no="{out_trade_no}"&subject="{subject}"&body="{body}"&total_fee="{total_fee}"&notify_url="{notify_url}"'
        append = '&sign="{sign}"&sign_type="RSA"'.format(sign=urllib.quote_plus(alipay.sign(dataString.format(**params))))
        payload = dataString.format(**params) + append
        data = {
            "requestType": "SafePay",
            "dataString": payload,
            "fromAppUrlScheme": self.url_scheme,
        }

        self.url = 'alipay://alipayclient/?' + urllib.quote(json.dumps(data, ensure_ascii=False, separators=(',',':')), '=:,&')
        self.payload = payload.decode('utf8')
        

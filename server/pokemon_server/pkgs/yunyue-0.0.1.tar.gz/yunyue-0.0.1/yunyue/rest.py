#!/usr/bin/env python
# coding=utf-8

import importlib
from flask import Flask, request, jsonify
app = Flask(__name__)
import backend

handlers = dict()
for name, pattern in backend.handlers:
    _module = importlib.import_module(pattern.split(':')[0])
    instance = getattr(_module, pattern.split(':')[1])()
    handlers[name] = instance

@app.route('/tasks/enqueue/<string:method>', methods=['GET', 'POST'])
def apply_task(method):
    payload = request.json
    if not payload:
        params = request.args.copy()
        params.update(request.form)
        payload = dict([(k, v) for k, v in params.items()])

    print payload
    handlers[method].apply_async((payload,))
    return jsonify(status=0, message='OK')

if __name__ == "__main__":
    app.run(port=9000, debug=True)

#!/usr/bin/env python
# encoding: utf-8

# def verify_with_public_key(msg, signature):
#     """使用当前文件中定义的_public_rsa_key来验证签名是否正确"""
#     signature = base64ToString(signature)
#     key = RSA.importKey(_public_rsa_key_itools)
#     h = SHA.new(msg)
#     verifier = PKCS1_v1_5.new(key)
#     return verifier.verify(h, signature)

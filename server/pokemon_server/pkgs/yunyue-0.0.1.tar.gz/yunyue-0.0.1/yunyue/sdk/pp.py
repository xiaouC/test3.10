#!/usr/bin/env python
# encoding: utf-8

"""
PP 助手
"""

import logging
logger = logging.getLogger(__name__)
import traceback
import json
import base64
from M2Crypto import RSA

def decrypt(public_key_file, base64_string):
    """PP 支付回调验证"""
    data = None
    try:
        ctx = RSA.load_pub_key(public_key_file)
        data = ctx.public_decrypt(base64.b64decode(base64_string), RSA.pkcs1_padding)
    except Exception, e:
        logger.error(e)
        logger.error(traceback.format_exc())
    finally:
        return json.loads(data)

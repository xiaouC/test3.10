#!/usr/bin/env python
# coding=utf-8

import hashlib
import requests
from celery import Task

class SendSMS(Task):
    """发送短信

    .. code-block:: python

        payload = {
            'mobile': '',
            'message': '',
        }
    """

    def run(self, payload):
        api_url = 'http://opsa.ourpalm.com/OPSA/sms/mt/send'
        params = {
            'from': '11',
            'tel': payload['mobile'],
            'msg': payload['message'],
            'mod': 'json',
            'debug': payload.get('debug', 'false'),
            'sgin': hashlib.md5('yunyuegame' + payload['mobile'].encode('utf-8') + payload['message'].encode('utf-8') + '117.79.132.147').hexdigest().upper(),
        }

        response = requests.get(api_url, params=params)
        result = response.json()
        return result

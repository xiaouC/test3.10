#!/usr/bin/env python
# encoding: utf-8

import os
import csv

def csv_loader(filename):
    with open(os.path.abspath(filename)) as fp:
        reader = csv.DictReader(fp, skipinitialspace=True)
        data = []
        for row in reader:
            data.append(dict([(key, unicode(value, 'utf-8')) for key, value in row.items()]))
        return data

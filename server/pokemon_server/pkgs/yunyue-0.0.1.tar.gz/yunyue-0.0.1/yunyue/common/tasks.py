#!/usr/bin/env python
# coding=utf-8

import os
import json
import hashlib
import socket
import apns
import mosquitto
import requests
from datetime import datetime
from werkzeug.datastructures import MultiDict
from celery import Task
apns_pool = dict()

class PushNotification(Task):
    """推送通知

    .. code-block:: python

        payload = {
            'device_type': 'android', # iOS
            'device_token': '',
            'environment': 'production',
            'bundle_id': '',
            'params': {}, # dict or json
        }
    """
    def run(self, payload):
        if isinstance(payload['params'], (str, unicode)):
            payload['params'] = json.loads(payload['params'])

        key = '{device_type}_{bundle_id}_{environment}'.format(**payload)
        conn  = apns_pool.get(key)

        if payload['device_type'].lower() == 'ios':
            apps_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'apps'))

            cert_file = os.path.join(apps_dir, '{bundle_id}/{environment}/cert.pem'.format(**payload))
            key_file = os.path.join(apps_dir, '{bundle_id}/{environment}/key.pem'.format(**payload))
            if not conn:
                conn = apns.APNs(use_sandbox=payload['environment'] == 'sandbox', cert_file=cert_file, key_file=key_file)
                apns_pool[key] = conn
            return conn.gateway_server.send_notification(payload['device_token'], apns.Payload(**payload['params']))
            # return [(device_token, since) for (device_token, since) in conn.feedback_server.items()]
        else:
            if not conn:
                conn = mosquitto.Mosquitto('{}/{}'.format(socket.gethostname(), payload['bundle_id']))

                def on_connect(mosq, obj, rc):
                    if rc == 0:
                        print("Connected successfully.")
                conn.on_connect = on_connect

                def on_disconnect(mosq, obj, rc):
                    conn.reconnect()
                    print 'Reconnecting ...'
                conn.on_disconnect = on_disconnect

                def on_publish(mosq, obj, mid):
                    print("Message " + str(mid) + " published.")
                conn.on_publish = on_publish

                conn.connect(os.environ.get('MOSQUITTO_HOST', '114.112.69.40'))
                apns_pool[key] = conn
            return conn.publish(payload['device_token'], payload['params']['alert'].encode('utf-8'), 0)

class SendEmail(Task):
    def run(self, payload):
        if 'subject' in payload and isinstance(payload['subject'], unicode):
            payload['subject'] = payload['subject'].encode('utf-8')
        payload = MultiDict([
            ('from', '圣将小喽啰 <me@rs79115.mailgun.org>'),
            ('subject', payload.get('subject', 'Event {0}'.format(datetime.now()))),
            ('text', payload.get('text', 'See attachment for more information.')),
        ])

        to = ['shengjiang-dev@rs79115.mailgun.org']
        to.extend(payload.get('to', []))
        payload.add('to', to)

        response = requests.post(
            'https://api.mailgun.net/v2/rs79115.mailgun.org/messages',
            auth=('api', 'key-39jfplmj6eg6t8q6cnq234jig4gyvk13'),
            data=payload,
            files=payload.get('files', MultiDict())
        )
        return response.text
